window.onload = function(){
document.onkeyup = teclas;
}

function teclas(event){
    var codigo = event.keyCode
    console.log(codigo);
}

